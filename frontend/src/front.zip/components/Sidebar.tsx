import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, UploadCloud, LogOut, BarChart3 } from 'lucide-react';

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Importar Dados', path: '/upload', icon: UploadCloud },
  ];

  return (
    <div className="w-64 bg-white h-screen border-r border-gray-200 flex flex-col fixed left-0 top-0">
      <div className="p-6 flex items-center gap-2 border-b border-gray-100">
        <BarChart3 className="text-blue-600 h-8 w-8" />
        <span className="text-xl font-bold text-gray-800">SaaS Sales</span>
      </div>
      <nav className="flex-1 p-4 space-y-2 mt-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <Icon size={20} />
              {item.name}
            </button>
          );
        })}
      </nav>
      <div className="p-4 border-t border-gray-100">
        <button 
          onClick={() => { localStorage.clear(); navigate('/login'); }}
          className="w-full flex items-center gap-3 px-4 py-3 text-red-500 font-medium hover:bg-red-50 rounded-xl"
        >
          <LogOut size={20} /> Sair
        </button>
      </div>
    </div>
  );
}
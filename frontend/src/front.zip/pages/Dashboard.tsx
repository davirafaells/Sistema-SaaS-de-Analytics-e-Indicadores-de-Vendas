import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { DollarSign, Package, ShoppingBag, LogOut } from 'lucide-react';

export default function Dashboard() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    // Busca os dados reais do nosso Backend
    api.get('/dashboard/resumo')
      .then(response => setData(response.data))
      .catch(err => console.error("Erro ao buscar dashboard", err));
  }, []);

  const logout = () => {
    localStorage.clear();
    window.location.href = '/login';
  };

  if (!data) return <div className="p-10 text-center">Carregando painel inteligente...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Painel de Vendas</h1>
        <button onClick={logout} className="flex items-center text-red-500 hover:text-red-700 font-medium">
          <LogOut className="mr-2 h-5 w-5" /> Sair
        </button>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Faturamento Total</p>
              <h3 className="text-2xl font-bold text-gray-800">R$ {Number(data.total_revenue).toLocaleString('pt-BR')}</h3>
            </div>
            <div className="bg-green-100 p-3 rounded-lg"><DollarSign className="text-green-600" /></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Itens Vendidos</p>
              <h3 className="text-2xl font-bold text-gray-800">{data.total_sales_count}</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg"><ShoppingBag className="text-blue-600" /></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Produtos Ativos</p>
              <h3 className="text-2xl font-bold text-gray-800">{data.active_products}</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg"><Package className="text-purple-600" /></div>
          </div>
        </div>
      </div>

      {/* Gráfico */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-800 mb-6">Evolução do Faturamento (por dia)</h3>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.sales_by_date}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="total_value" stroke="#3b82f6" strokeWidth={3} dot={{ r: 6 }} activeDot={{ r: 8 }} name="Faturamento R$" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Trash2, ShoppingBag } from 'lucide-react';

interface Sale {
  id: number;
  product_name: string;
  date: string;
  value: number;
  quantity: number;
  total_value: number;
}

export default function SalesList() {
  const [sales, setSales] = useState<Sale[]>([]);

  const loadSales = async () => {
    const response = await api.get('/sales/');
    setSales(response.data);
  };

  useEffect(() => {
    loadSales();
  }, []);

  const handleDelete = async (id: number) => {
    if (window.confirm("Tem certeza que deseja excluir esta venda?")) {
      await api.delete(`/sales/${id}`);
      loadSales(); // Recarrega a lista
    }
  };

  return (
    <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-md p-8 border border-gray-100">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold flex items-center text-gray-800">
          <ShoppingBag className="mr-2 text-blue-600" /> Histórico de Vendas
        </h2>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="p-4 font-semibold text-gray-600">Data</th>
              <th className="p-4 font-semibold text-gray-600">Produto</th>
              <th className="p-4 font-semibold text-gray-600 text-center">Qtd</th>
              <th className="p-4 font-semibold text-gray-600">Unitário</th>
              <th className="p-4 font-semibold text-gray-600">Total</th>
              <th className="p-4 font-semibold text-gray-600 text-center">Ações</th>
            </tr>
          </thead>
          <tbody>
            {sales.map((sale) => (
              <tr key={sale.id} className="border-b hover:bg-gray-50 transition-colors">
                <td className="p-4 text-gray-700">{new Date(sale.date).toLocaleDateString()}</td>
                <td className="p-4 font-medium text-gray-900">{sale.product_name}</td>
                <td className="p-4 text-center text-gray-700">{sale.quantity}</td>
                <td className="p-4 text-gray-700">R$ {sale.value.toFixed(2)}</td>
                <td className="p-4 font-bold text-blue-600">R$ {sale.total_value.toFixed(2)}</td>
                <td className="p-4 text-center">
                  <button 
                    onClick={() => handleDelete(sale.id)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {sales.length === 0 && (
          <div className="text-center py-10 text-gray-400">Nenhuma venda encontrada.</div>
        )}
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import api from '../services/api';
import Papa from 'papaparse';
import { Upload as UploadIcon, CheckCircle, AlertCircle, FileSpreadsheet, PlusCircle } from 'lucide-react';

export default function Upload() {
  const [activeTab, setActiveTab] = useState<'csv' | 'manual'>('csv');
  const [status, setStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);

  // Estados CSV
  const [file, setFile] = useState<File | null>(null);
  const [columns, setColumns] = useState<string[]>([]);
  const [mapping, setMapping] = useState({
    id_produto: '', produto: '', data: '', valor: '', quantidade: '', valor_total: ''
  });

  // Estados Manual
  const [manualData, setManualData] = useState({
    id_produto: '', nome_produto: '', data: '', valor_unitario: '', quantidade: 1, valor_total: ''
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      Papa.parse(selectedFile, {
        preview: 1,
        complete: (results: any) => {
          if (results.data && results.data.length > 0) setColumns(results.data[0]);
        }
      });
    }
  };

  const handleCsvUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    Object.entries(mapping).forEach(([key, value]) => formData.append(key, value));

    try {
      await api.post('/upload/', formData);
      setStatus({ type: 'success', msg: 'CSV processado com sucesso!' });
      setFile(null);
    } catch (err: any) {
      setStatus({ type: 'error', msg: 'Erro no upload do CSV.' });
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/sales/manual', manualData);
      setStatus({ type: 'success', msg: 'Venda registada manualmente!' });
      setManualData({ id_produto: '', nome_produto: '', data: '', valor_unitario: '', quantidade: 1, valor_total: '' });
    } catch (err: any) {
      setStatus({ type: 'error', msg: 'Erro ao registar venda.' });
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md p-8 border border-gray-100">
      <div className="flex mb-8 bg-gray-100 p-1 rounded-xl">
        <button 
          onClick={() => {setActiveTab('csv'); setStatus(null);}}
          className={`flex-1 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'csv' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}
        >
          Importar CSV
        </button>
        <button 
          onClick={() => {setActiveTab('manual'); setStatus(null);}}
          className={`flex-1 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'manual' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}
        >
          Lançamento Manual
        </button>
      </div>

      {activeTab === 'csv' ? (
        <div className="animate-in fade-in duration-300">
          <h2 className="text-xl font-bold mb-6 flex items-center text-gray-800">
            <UploadIcon className="mr-2 text-blue-600" /> Upload de Relatório
          </h2>
          <div className="mb-8 border-2 border-dashed border-blue-200 bg-blue-50 rounded-xl p-8 text-center">
            <input type="file" className="hidden" id="fileInput" accept=".csv" onChange={handleFileChange} />
            <label htmlFor="fileInput" className="cursor-pointer flex flex-col items-center">
              <FileSpreadsheet className="h-12 w-12 text-blue-400 mb-2" />
              <span className="text-blue-700 font-semibold">{file ? file.name : "Clique para selecionar o CSV"}</span>
            </label>
          </div>
          {columns.length > 0 && (
            <form onSubmit={handleCsvUpload} className="space-y-4">
              {Object.keys(mapping).map((key) => (
                <div key={key} className="flex flex-col">
                  <label className="text-xs font-bold text-gray-500 uppercase mb-1">{key.replace('_', ' ')}:</label>
                  <select 
                    required 
                    className="p-2 border rounded-lg text-sm bg-gray-50"
                    value={(mapping as any)[key]}
                    onChange={(e) => setMapping({...mapping, [key]: e.target.value})}
                  >
                    <option value="">Selecione a coluna...</option>
                    {columns.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              ))}
              <button className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-colors">Importar Dados</button>
            </form>
          )}
        </div>
      ) : (
        <form onSubmit={handleManualSubmit} className="space-y-4 animate-in fade-in duration-300">
          <h2 className="text-xl font-bold mb-6 flex items-center text-gray-800">
            <PlusCircle className="mr-2 text-green-600" /> Novo Lançamento
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">ID Produto:</label>
              <input className="p-3 border rounded-lg bg-gray-50" required value={manualData.id_produto} onChange={e => setManualData({...manualData, id_produto: e.target.value})} />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">Nome Produto:</label>
              <input className="p-3 border rounded-lg bg-gray-50" required value={manualData.nome_produto} onChange={e => setManualData({...manualData, nome_produto: e.target.value})} />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">Data:</label>
              <input type="date" className="p-3 border rounded-lg bg-gray-50" required value={manualData.data} onChange={e => setManualData({...manualData, data: e.target.value})} />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">Qtd:</label>
              <input type="number" className="p-3 border rounded-lg bg-gray-50" required value={manualData.quantidade} onChange={e => setManualData({...manualData, quantidade: parseInt(e.target.value)})} />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">Preço Unit.:</label>
              <input type="number" step="0.01" className="p-3 border rounded-lg bg-gray-50" required value={manualData.valor_unitario} onChange={e => setManualData({...manualData, valor_unitario: e.target.value})} />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1">Valor Total:</label>
              <input type="number" step="0.01" className="p-3 border rounded-lg bg-gray-50 font-bold text-blue-600" required value={manualData.valor_total} onChange={e => setManualData({...manualData, valor_total: e.target.value})} />
            </div>
          </div>
          <button className="w-full bg-green-600 text-white py-4 rounded-xl font-bold hover:bg-green-700 transition-colors">Salvar Registro</button>
        </form>
      )}

      {status && (
        <div className={`mt-6 p-4 rounded-lg flex items-center ${status.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {status.type === 'success' ? <CheckCircle className="mr-2" /> : <AlertCircle className="mr-2" />}
          {status.msg}
        </div>
      )}
    </div>
  );
}
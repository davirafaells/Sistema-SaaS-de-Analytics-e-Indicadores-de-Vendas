from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.database import get_db
from core.dependencies import get_current_company_id
from schemas.dashboard import DashboardSummary
from services.dashboard_service import DashboardService

router = APIRouter(prefix="/dashboard", tags=["Analytics e Dashboard"])

@router.get("/resumo", response_model=DashboardSummary)
def get_dashboard_summary(
    db: Session = Depends(get_db),
    company_id: int = Depends(get_current_company_id) # Trava de segurança: só logados
):
    # Chama o serviço que faz as contas e devolve o JSON pronto
    return DashboardService.get_summary(db, company_id)
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.database import get_db
from core.dependencies import get_current_company_id
from schemas.sale import SaleManualCreate
from services.sale_service import SaleService

router = APIRouter(prefix="/sales", tags=["Vendas"])

@router.post("/manual")
async def create_manual_sale(
    data: SaleManualCreate,
    db: Session = Depends(get_db),
    company_id: int = Depends(get_current_company_id)
):
    return SaleService.create_manual_sale(db, company_id, data)
from pydantic import BaseModel
from datetime import date
from decimal import Decimal

# Como um Produto vai aparecer na tabela
class ProductResponse(BaseModel):
    id: int
    external_id: str
    name: str
    is_active: bool

# Como uma Venda vai aparecer na tabela
class SaleResponse(BaseModel):
    id: int
    date: date
    value: Decimal
    quantity: int
    product_name: str # Vamos mandar o nome do produto junto para facilitar pro Frontend
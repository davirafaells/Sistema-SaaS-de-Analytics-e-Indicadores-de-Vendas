from pydantic import BaseModel
from datetime import date
from decimal import Decimal

class SaleManualCreate(BaseModel):
    id_produto: str
    nome_produto: str
    data: date
    valor_unitario: Decimal
    quantidade: int
    valor_total: Decimal
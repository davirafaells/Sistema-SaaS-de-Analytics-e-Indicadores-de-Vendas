from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from core.database import engine, Base
import domain.models
from api.auth import router as auth_router
from api.upload import router as upload_router
from api.dashboard import router as dashboard_router
from api.report import router as report_router
from api import sales # No topo junto aos outros imports
# Garante que as tabelas existam
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="SaaS Micro-Analytics de Vendas",
    description="Camada de inteligência sobre vendas"
)

# Configuração de CORS (Obrigatório para o React conseguir conversar com o Python)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Em produção, trocaremos para o domínio do seu frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registra as rotas de autenticação
app.include_router(auth_router)
app.include_router(upload_router) 
app.include_router(dashboard_router)
app.include_router(report_router)
app.include_router(sales.router)

@app.get("/")
def root():
    return {"mensagem": "API rodando, banco sincronizado e rotas ativas!"}
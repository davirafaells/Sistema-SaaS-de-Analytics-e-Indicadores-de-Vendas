from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.database import Base

# --- TABELAS DA TAREFA 1 (FUNDAÇÃO) ---

class Company(Base):
    __tablename__ = "company"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    trial_start_date = Column(DateTime, default=func.now())
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    
    users = relationship("User", back_populates="company")
    jobs = relationship("ProcessingJob", back_populates="company")
    products = relationship("Product", back_populates="company")
    uploads = relationship("Upload", back_populates="company")
    sales = relationship("Sale", back_populates="company")

class User(Base):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=True) 
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_saas_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())

    company = relationship("Company", back_populates="users")

class ProcessingJob(Base):
    __tablename__ = "processing_job"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=False)
    status = Column(String, default="pendente") 
    file_hash = Column(String, nullable=False) 
    created_at = Column(DateTime, default=func.now())

    company = relationship("Company", back_populates="jobs")

# --- TABELAS DA TAREFA 2 (INSERÇÃO DE DADOS E CATÁLOGO) ---

class Upload(Base):
    __tablename__ = "upload"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=False)
    filename = Column(String, nullable=False)
    file_hash = Column(String, nullable=False) # Regra: Mesmo arquivo não pode ser importado 2x
    created_at = Column(DateTime, default=func.now())

    company = relationship("Company", back_populates="uploads")
    sales = relationship("Sale", back_populates="upload")

class Product(Base):
    __tablename__ = "product"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=False)
    external_id = Column(String, nullable=False, index=True) # O 'id_produto' que vem do CSV
    name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True) # Regra: Usuário pode inativar produto
    created_at = Column(DateTime, default=func.now())

    company = relationship("Company", back_populates="products")
    sales = relationship("Sale", back_populates="product")

class Sale(Base):
    __tablename__ = "sale"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=False)
    upload_id = Column(Integer, ForeignKey("upload.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("product.id"), nullable=False)
    
    date = Column(Date, nullable=False)
    value = Column(Numeric(10, 2), nullable=False) # Valor da venda unitário
    quantity = Column(Integer, nullable=False)
    total_value = Column(Numeric(10, 2), nullable=False) # <-- NOVA COLUNA ADICIONADA AQUI
    
    is_deleted = Column(Boolean, default=False) # Regra: Exclusão é soft delete
    created_at = Column(DateTime, default=func.now())

    company = relationship("Company", back_populates="sales")
    upload = relationship("Upload", back_populates="sales")
    product = relationship("Product", back_populates="sales")
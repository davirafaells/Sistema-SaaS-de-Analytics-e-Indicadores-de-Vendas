from sqlalchemy.orm import Session
from sqlalchemy import func
from domain.models import Sale, Product

class DashboardService:
    @staticmethod
    def get_summary(db: Session, company_id: int):
        # 1. Calcula o Faturamento Real (AGORA USA A NOVA COLUNA total_value)
        total_revenue = db.query(func.sum(Sale.total_value)).filter(
            Sale.company_id == company_id,
            Sale.is_deleted == False
        ).scalar() or 0.0

        # 2. Calcula a Quantidade Total de Itens Vendidos (Mantido igual)
        total_sales_count = db.query(func.sum(Sale.quantity)).filter(
            Sale.company_id == company_id,
            Sale.is_deleted == False
        ).scalar() or 0

        # 3. Conta quantos produtos ativos a empresa tem no catálogo (Mantido igual)
        active_products = db.query(Product).filter(
            Product.company_id == company_id,
            Product.is_active == True
        ).count()

        # 4. Agrupa as vendas por dia para o gráfico (AGORA USA A NOVA COLUNA total_value)
        daily_sales_query = db.query(
            Sale.date, 
            func.sum(Sale.total_value).label('total_value')
        ).filter(
            Sale.company_id == company_id,
            Sale.is_deleted == False
        ).group_by(Sale.date).order_by(Sale.date).all()

        # Converte a resposta do banco para o formato que o Frontend precisa
        sales_by_date = [
            {"date": row.date, "total_value": row.total_value} 
            for row in daily_sales_query
        ]

        return {
            "total_revenue": total_revenue,
            "total_sales_count": total_sales_count,
            "active_products": active_products,
            "sales_by_date": sales_by_date
        }
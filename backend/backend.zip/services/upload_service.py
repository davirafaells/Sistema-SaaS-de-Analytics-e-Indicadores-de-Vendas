import pandas as pd
import io
import hashlib
from fastapi import HTTPException
from sqlalchemy.orm import Session
from domain.models import Upload, Product, Sale
from schemas.upload import MappedColumns

class UploadService:
    @staticmethod
    def process_file(db: Session, file_bytes: bytes, filename: str, columns: MappedColumns, company_id: int):
        # Regra de negócio: Mesmo arquivo não pode ser importado 2x
        file_hash = hashlib.md5(file_bytes).hexdigest()
        upload_existente = db.query(Upload).filter(
            Upload.company_id == company_id, 
            Upload.file_hash == file_hash
        ).first()
        
        if upload_existente:
            raise HTTPException(status_code=400, detail="Este arquivo já foi importado anteriormente.")

        # Cria o registro do Upload
        novo_upload = Upload(
            company_id=company_id,
            filename=filename,
            file_hash=file_hash
        )
        db.add(novo_upload)
        db.flush() # Para gerar o ID do upload no banco

        # Lendo o arquivo CSV com Pandas
        df = pd.read_csv(io.BytesIO(file_bytes))
        linhas_importadas = 0

        for _, row in df.iterrows():
            ext_id = str(row[columns.id_produto])
            nome_prod = str(row[columns.produto])

            # Verifica se o produto já existe para a empresa
            produto = db.query(Product).filter(
                Product.company_id == company_id,
                Product.external_id == ext_id
            ).first()

            # Se não existir, cria um novo no catálogo
            if not produto:
                produto = Product(
                    company_id=company_id,
                    external_id=ext_id,
                    name=nome_prod
                )
                db.add(produto)
                db.flush()

            # Cria a Venda (Sale) salvando o valor total do ERP
            nova_venda = Sale(
                company_id=company_id,
                upload_id=novo_upload.id,
                product_id=produto.id,
                date=pd.to_datetime(row[columns.data]).date(),
                value=float(row[columns.valor]),
                quantity=int(row[columns.quantidade]),
                total_value=float(row[columns.valor_total]) # <-- A NOSSA NOVA COLUNA AQUI
            )
            db.add(nova_venda)
            linhas_importadas += 1

        db.commit()
        return {"linhas_importadas": linhas_importadas, "message": "Sucesso"}